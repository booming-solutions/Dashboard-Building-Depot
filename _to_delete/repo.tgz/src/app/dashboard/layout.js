/* ============================================================
   BESTAND: layout.js
   KOPIEER NAAR: src/app/dashboard/layout.js
   (overschrijft de bestaande layout.js)    

   WIJZIGINGEN V27.19:
   - Finance: 'AR-ontwikkeling' link toegevoegd
     (/dashboard/finance/ar).
   - Versie naar V27.19

   WIJZIGINGEN V27.18:
   - Logistiek menu: 'Schepen (wereldkaart)' toegevoegd
     (/dashboard/logistics/vessel-map).
   - Versie naar V27.18

   WIJZIGINGEN V27.17:
   - Marketing menu toegevoegd (Website foto-status →
     /dashboard/marketing/website). Zichtbaar voor
     admin/cfo/manager (pas de rollenlijst aan op de regel
     'const isMarketing = ...').
   - Versie naar V27.17

   WIJZIGINGEN V27.16:
   - Logistiek menu toegevoegd met Order Flow portal
     (/dashboard/logistics/order-flow). Zichtbaar voor
     admin/cfo/manager/ap_approver/ap_clerk (pas de rollenlijst
     aan op de regel 'const isLogistics = ...').
   - Versie naar V27.16

   WIJZIGINGEN V27.15:
   - Finance menu vereenvoudigd tot 3 hoofdlinks:
     · AP Dashboard  (van hieruit verder navigeren)
     · AP Sandbox    (van hieruit verder navigeren)
     · Rapportages
     Alle sub-pagina's (Werkstroom, Upload, Auto-match, Eagle Sync,
     Worklist, PCS Import, Bank Import) zijn nu alleen bereikbaar
     via de tegels op de dashboards zelf.
   - Versie naar V27.15

   WIJZIGINGEN V27.14:
   - Omzet/Index: badge (concept) toegevoegd.
   - Voorraad/Price Changes: tijdelijk verwijderd uit menu
     (fout zit erin, Jeroen lost eerst op voor terugplaatsing).
   - Finance: 'Rapportages' link toegevoegd.
   - Finance: 'AP Sandbox' toegevoegd als uitvouwbaar submenu.
   - Versie naar V27.14

   WIJZIGINGEN V27.13:
   - Finance menu toegevoegd (Accounts Payable suite). Zichtbaar
     voor admin/cfo/ap_approver/ap_clerk. Submenu's:
     · Accounts Payable (dashboard)
     · Werkstroom
     · Data Upload
     · Auto-match
     · Eagle Sync
     · Project Clean Up (PCS / Bank / Werklijst)
   - Versie naar V27.13

   WIJZIGINGEN V27.12:
   - Admin menu: Salaris Import (Celery C4 + C16) toegevoegd
   - Versie naar V27.12

   WIJZIGINGEN V27.11:
   - Urenplanning menu-item verwijderd (pagina was overbodig)
   - Admin menu: Dyflexis Planning + Dyflexis Actuals toegevoegd

   WIJZIGINGEN V27.07 (oud):
   - BUM-rol opgeheven, BUMs zijn nu 'manager'
   - isBum check vervangen door isManager
   - Urenplanning zichtbaar voor admin + manager
   ============================================================ */
'use client';

import { useState, useEffect, useCallback } from 'react';
import { createClient } from '@/lib/supabase';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import PageTracker from '@/components/PageTracker';
import DataStatusPopup from '@/components/DataStatusPopup';

const APP_VERSION = 'V27.19';

function NavSubItem({ item, pathname, sidebarOpen }) {
  const hasChildren = item.children && item.children.length > 0;
  const isChildActive = hasChildren && item.children.some(c => pathname === c.href);
  const isSelfActive = pathname === item.href && !isChildActive;
  const isActive = isSelfActive || isChildActive;
  const [subOpen, setSubOpen] = useState(isChildActive);
  useEffect(() => { if (isChildActive) setSubOpen(true); }, [isChildActive]);

  if (!hasChildren) {
    return (
      <Link href={item.href}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg text-[13px] font-medium transition-all ${pathname === item.href ? 'bg-[#1B3A5C]/10 text-[#1B3A5C] font-semibold' : 'text-[#1B3A5C]/50 hover:text-[#1B3A5C] hover:bg-white/50'}`}>
        <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: pathname === item.href ? '#1B3A5C' : 'transparent', border: pathname === item.href ? 'none' : '1px solid rgba(27,58,92,0.25)' }} />
        <span className="flex-1">{item.label}</span>
        {item.badge && <span className="text-[9px] italic text-[#1B3A5C]/40 font-normal">{item.badge}</span>}
      </Link>
    );
  }

  return (
    <div>
      <button onClick={() => setSubOpen(!subOpen)}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg text-[13px] font-medium transition-all w-full ${isActive ? 'text-[#1B3A5C] font-semibold' : 'text-[#1B3A5C]/50 hover:text-[#1B3A5C] hover:bg-white/50'}`}>
        <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: isActive ? '#1B3A5C' : 'transparent', border: isActive ? 'none' : '1px solid rgba(27,58,92,0.25)' }} />
        <span className="flex-1 text-left">{item.label}</span>
        <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5" className={`transition-transform duration-200 ${subOpen ? 'rotate-180' : ''}`}><path d="M3 4.5L6 7.5L9 4.5" /></svg>
      </button>
      {subOpen && (
        <div className="ml-4 mt-0.5 space-y-0.5 border-l border-[#1B3A5C]/10 pl-2">
          {item.children.map(child => (
            <Link key={child.href} href={child.href}
              className={`flex items-center gap-2 px-2 py-1.5 rounded text-[12px] transition-all ${pathname === child.href ? 'text-[#1B3A5C] font-semibold bg-[#1B3A5C]/5' : 'text-[#1B3A5C]/40 hover:text-[#1B3A5C] hover:bg-white/30'}`}>
              {child.label}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function NavDropdown({ icon, label, items, pathname, sidebarOpen }) {
  const isAnyActive = items.some(item => pathname === item.href || pathname.startsWith(item.href + '/'));
  const [open, setOpen] = useState(isAnyActive);
  useEffect(() => { if (isAnyActive) setOpen(true); }, [isAnyActive]);

  if (!sidebarOpen) {
    return (
      <div className="relative group">
        <div className={`flex items-center justify-center px-3 py-2.5 rounded-lg text-sm font-medium transition-all cursor-pointer ${isAnyActive ? 'bg-[#1B3A5C] text-white' : 'text-[#1B3A5C]/60 hover:text-[#1B3A5C] hover:bg-white/50'}`}>
          <span className="text-base flex-shrink-0">{icon}</span>
        </div>
        <div className="absolute left-full top-0 ml-2 bg-white rounded-lg shadow-xl border border-gray-200 py-1 min-w-[220px] hidden group-hover:block z-50">
          <p className="px-3 py-1.5 text-[10px] font-bold text-[#1B3A5C]/40 uppercase tracking-wider">{label}</p>
          {items.map(item => {
            if (item.children) {
              return (
                <div key={item.href}>
                  <p className="px-3 pt-2 pb-1 text-[9px] font-bold text-[#1B3A5C]/30 uppercase">{item.label}</p>
                  {item.children.map(child => (
                    <Link key={child.href} href={child.href} className={`block px-4 py-1.5 text-[13px] transition-all ${pathname === child.href ? 'bg-[#1B3A5C]/10 text-[#1B3A5C] font-semibold' : 'text-gray-500 hover:bg-gray-50 hover:text-[#1B3A5C]'}`}>{child.label}</Link>
                  ))}
                </div>
              );
            }
            return <Link key={item.href} href={item.href} className={`block px-3 py-2 text-sm transition-all ${pathname === item.href ? 'bg-[#1B3A5C]/10 text-[#1B3A5C] font-semibold' : 'text-gray-600 hover:bg-gray-50 hover:text-[#1B3A5C]'}`}>{item.label}{item.badge ? <span className="text-[9px] italic text-gray-400 ml-2">{item.badge}</span> : ''}</Link>;
          })}
        </div>
      </div>
    );
  }

  return (
    <div>
      <button onClick={() => setOpen(!open)}
        className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all w-full ${isAnyActive ? 'bg-[#1B3A5C] text-white' : 'text-[#1B3A5C]/60 hover:text-[#1B3A5C] hover:bg-white/50'}`}>
        <span className="text-base flex-shrink-0">{icon}</span>
        <span className="flex-1 text-left">{label}</span>
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5" className={`transition-transform duration-200 ${open ? 'rotate-180' : ''}`}><path d="M3 4.5L6 7.5L9 4.5" /></svg>
      </button>
      {open && (
        <div className="ml-5 mt-0.5 space-y-0.5 border-l-2 border-[#1B3A5C]/10 pl-3">
          {items.map(item => (
            <NavSubItem key={item.href} item={item} pathname={pathname} sidebarOpen={sidebarOpen} />
          ))}
        </div>
      )}
    </div>
  );
}

function LoginModal({ show, onClose, supabase, onSuccess }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  if (!show) return null;

  async function handleLogin() {
    setLoading(true); setError('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) { setError(error.message); setLoading(false); }
    else { onSuccess(); onClose(); setEmail(''); setPassword(''); setLoading(false); }
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.45)' }} onClick={onClose}>
      <div className="bg-white rounded-2xl p-7 w-[360px] shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-[#1B3A5C] flex items-center justify-center"><span className="text-white text-lg">🔑</span></div>
          <div><h3 className="text-[16px] font-bold text-[#1a0a04]">Inloggen</h3><p className="text-[12px] text-[#6b5240]">Administrator toegang</p></div>
        </div>
        <input type="email" value={email} onChange={e => { setEmail(e.target.value); setError(''); }}
          className="w-full px-4 py-2.5 rounded-lg border border-[#e5ddd4] text-[14px] mb-3 focus:outline-none focus:border-[#1B3A5C]" placeholder="E-mailadres" autoFocus />
        <input type="password" value={password} onChange={e => { setPassword(e.target.value); setError(''); }} onKeyDown={e => e.key === 'Enter' && handleLogin()}
          className="w-full px-4 py-2.5 rounded-lg border border-[#e5ddd4] text-[14px] mb-2 focus:outline-none focus:border-[#1B3A5C]" placeholder="Wachtwoord" />
        {error && <p className="text-[12px] text-red-500 mb-2">{error}</p>}
        <div className="flex gap-2 mt-4">
          <button onClick={() => { onClose(); setEmail(''); setPassword(''); setError(''); }} className="flex-1 py-2.5 rounded-lg bg-[#faf7f4] text-[#6b5240] text-[13px] font-semibold border border-[#e5ddd4]">Annuleren</button>
          <button onClick={handleLogin} disabled={loading} className="flex-1 py-2.5 rounded-lg bg-[#1B3A5C] text-white text-[13px] font-semibold disabled:opacity-50">{loading ? 'Laden...' : 'Inloggen'}</button>
        </div>
      </div>
    </div>
  );
}

export default function DashboardLayout({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showLogin, setShowLogin] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const router = useRouter();
  const pathname = usePathname();
  const supabase = createClient();

  const loadProfile = useCallback(async (userId) => {
    try {
      const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).single();
      if (error) {
        console.warn('Profile load failed, retrying in 1s...', error.message);
        setTimeout(async () => {
          const { data: retryData } = await supabase.from('profiles').select('*').eq('id', userId).single();
          if (retryData) {
            console.log('Profile loaded on retry:', retryData.role);
            setProfile(retryData);
          }
        }, 1000);
      } else {
        console.log('Profile loaded:', data.role);
        setProfile(data);
      }
    } catch (e) {
      console.error('Profile load error:', e);
    }
  }, [supabase]);

  useEffect(() => {
    async function init() {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        await loadProfile(session.user.id);
      }
      const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
        if (session?.user) {
          setUser(session.user);
          setTimeout(() => loadProfile(session.user.id), 500);
        } else {
          setUser(null);
          setProfile(null);
        }
      });
      return () => subscription?.unsubscribe();
    }
    init();
  }, []);

  async function getUser() {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user) {
      setUser(session.user);
      await loadProfile(session.user.id);
    } else {
      setUser(null);
      setProfile(null);
    }
  }

  async function handleLogout() { await supabase.auth.signOut(); setUser(null); setProfile(null); router.push('/'); router.refresh(); }
  function handleRefresh() { setRefreshing(true); window.location.reload(); }

  const isAdmin = profile?.role === 'admin';
  const isManager = profile?.role === 'manager';
  const allowedReports = profile?.allowed_reports || [];
  const hasReport = (id) => isAdmin || allowedReports.includes(id);

  const REPORT_MAP = {
    '/dashboard/sales': 'sales',
    '/dashboard/sales/forecast': 'sales',
    '/dashboard/sales/index': 'sales_index',
    '/dashboard/sales/discounts': 'sales_discounts',
    '/dashboard/sales/traffic': 'sales_traffic',
    '/dashboard/inventory/budget': 'inventory_budget',
    '/dashboard/inventory/buying': 'inventory_buying',
    '/dashboard/inventory/negative': 'inventory_negative',
    '/dashboard/inventory/health': 'inventory_health',
    '/dashboard/inventory/stockrisk': 'inventory_stockrisk',
    '/dashboard/inventory/price-changes': 'inventory_price_changes',
    '/dashboard/hr/salary': 'hr_payroll',
    '/dashboard/hr/urentarget': 'hr_urentarget',
    '/dashboard/hr/urenplanning-overview': 'hr_urenplanning_overview',
  };

  // Sales menu: Actuals, Forecast (concept), Index, Bezoekers en Conversie
  const omzetItemsAll = [
    { href: '/dashboard/sales', label: 'Actuals' },
    { href: '/dashboard/sales/forecast', label: 'Forecast', badge: '(concept)' },
    { href: '/dashboard/sales/index', label: 'Index', badge: '(concept)' },
    { href: '/dashboard/sales/discounts', label: 'Kortingen' },
    { href: '/dashboard/sales/traffic', label: 'Bezoekers en Conversie' },
  ];
  const voorraadItemsAll = [
    { href: '/dashboard/inventory/budget', label: 'Voorraad vs Budget' },
    { href: '/dashboard/inventory/stockrisk', label: 'Stock Risk Alert', children: [
      { href: '/dashboard/inventory/stockrisk', label: 'Totaaloverzicht' },
      { href: '/dashboard/inventory/stockrisk/appliances-houseware', label: 'Appliances & Houseware' },
      { href: '/dashboard/inventory/stockrisk/building-materials', label: 'Building Materials' },
      { href: '/dashboard/inventory/stockrisk/hardware', label: 'Hardware' },
      { href: '/dashboard/inventory/stockrisk/living', label: 'Living' },
      { href: '/dashboard/inventory/stockrisk/sanitair-keukens', label: 'Sanitair & Keukens' },
    ]},
    { href: '/dashboard/inventory/negative', label: 'Negatieve Voorraad' },
    { href: '/dashboard/inventory/health', label: 'Gezondheid Voorraden', children: [
      { href: '/dashboard/inventory/health', label: 'Totaaloverzicht' },
      { href: '/dashboard/inventory/health/appliances-houseware', label: 'Appliances & Houseware' },
      { href: '/dashboard/inventory/health/building-materials', label: 'Building Materials' },
      { href: '/dashboard/inventory/health/hardware', label: 'Hardware' },
      { href: '/dashboard/inventory/health/living', label: 'Living' },
      { href: '/dashboard/inventory/health/sanitair-keukens', label: 'Sanitair & Keukens' },
    ]},
  ];
  const hrItemsAll = [
    { href: '/dashboard/hr/salary', label: 'Salariskosten' },
    { href: '/dashboard/hr/urentarget', label: 'Urentarget', badge: '(concept)' },
    { href: '/dashboard/hr/urenplanning-overview', label: 'Urenplanning Overzicht', badge: '(concept)', visible: isAdmin },
  ];

  // Finance menu — Accounts Payable suite
  const isFinance = ['admin', 'cfo', 'ap_approver', 'ap_clerk'].includes(profile?.role);
  const financeItems = [
    { href: '/dashboard/finance/ap', label: 'AP Dashboard' },
    { href: '/dashboard/finance/sandbox-ap', label: 'AP Sandbox', badge: '(test)' },
    { href: '/dashboard/finance/reports', label: 'Rapportages' },
    { href: '/dashboard/finance/ar', label: 'AR-ontwikkeling' },
    { href: '/dashboard/finance/factuurstatus', label: 'Factuur status', everyone: true },
  ];
  // Finance-menu tonen aan finance-rollen (volledig) of aan iedereen (alleen de 'everyone'-items)
  const visibleFinanceItems = isFinance ? financeItems : financeItems.filter(i => i.everyone);

  // Logistiek menu — Order Flow portal
  const isLogistics = ['admin', 'cfo', 'manager', 'ap_approver', 'ap_clerk'].includes(profile?.role);
  const logisticsItems = [
    { href: '/dashboard/logistics/order-flow', label: 'Order Flow' },
    { href: '/dashboard/logistics/vessel-map', label: 'Schepen (wereldkaart)' },
  ];

  // Marketing menu — Website foto-status
  const isMarketing = ['admin', 'cfo', 'manager'].includes(profile?.role);
  const marketingItems = [
    { href: '/dashboard/marketing/website', label: 'Website foto-status' },
  ];

  const omzetItems = omzetItemsAll.filter(item => hasReport(REPORT_MAP[item.href]));
  const voorraadItems = voorraadItemsAll.filter(item => hasReport(REPORT_MAP[item.href]));
  const hrItems = hrItemsAll.filter(item => {
    if (typeof item.visible !== 'undefined') return item.visible;
    return hasReport(REPORT_MAP[item.href]);
  });
  const adminItems = [
    { href: '/dashboard/admin', label: 'Data Upload', icon: '⬆️' },
    { href: '/dashboard/admin/data-status', label: 'Data Status', icon: '🩺' },
    { href: '/dashboard/admin/users', label: 'Gebruikersbeheer', icon: '👥' },
    { href: '/dashboard/admin/dyflexis-import', label: 'Dyflexis Planning', icon: '📅' },
    { href: '/dashboard/admin/dyflexis-actuals', label: 'Dyflexis Actuals', icon: '📊' },
    { href: '/dashboard/admin/salary-import', label: 'Salaris Import', icon: '💰' },
    { href: '/dashboard/finance/ledger-upload', label: 'Ledger laden', icon: '📒' },
    { href: '/dashboard/admin/stats', label: 'Statistieken', icon: '📊' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <LoginModal show={showLogin} onClose={() => setShowLogin(false)} supabase={supabase} onSuccess={getUser} />
      <PageTracker />
      <DataStatusPopup />

      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} flex flex-col transition-all duration-300 fixed h-full z-40`} style={{ background: 'linear-gradient(180deg, #e8eff7 0%, #dce6f1 100%)' }}>
        <div className="p-4 flex items-center gap-3 border-b border-[#c5d4e6]">
          <img src="/logo.png" alt="Logo" className="h-9 w-9 flex-shrink-0 rounded-lg" />
          {sidebarOpen && <span className="font-bold text-[#1B3A5C] leading-tight" style={{ fontSize: '14px', letterSpacing: '0.02em', wordBreak: 'break-word', lineHeight: '1.2' }}>BOOMING SOLUTIONS</span>}
        </div>

        <nav className="flex-1 py-4 px-3 overflow-y-auto">
          <div className="space-y-1">
            {/* Overzicht, Rapportages en Bestanden zijn verborgen */}
            {omzetItems.length > 0 && <NavDropdown icon="📈" label="Omzet" items={omzetItems} pathname={pathname} sidebarOpen={sidebarOpen} />}
            {voorraadItems.length > 0 && <NavDropdown icon="📦" label="Voorraad" items={voorraadItems} pathname={pathname} sidebarOpen={sidebarOpen} />}
            {hrItems.length > 0 && <NavDropdown icon="💰" label="HR" items={hrItems} pathname={pathname} sidebarOpen={sidebarOpen} />}
            {user && visibleFinanceItems.length > 0 && <NavDropdown icon="💼" label="Finance" items={visibleFinanceItems} pathname={pathname} sidebarOpen={sidebarOpen} />}
            {isLogistics && <NavDropdown icon="🚢" label="Logistiek" items={logisticsItems} pathname={pathname} sidebarOpen={sidebarOpen} />}
            {isMarketing && <NavDropdown icon="📣" label="Marketing" items={marketingItems} pathname={pathname} sidebarOpen={sidebarOpen} />}
          </div>
          {isAdmin && (
            <div className="mt-6 pt-4 border-t border-[#c5d4e6]">
              {sidebarOpen && <p className="text-[10px] text-[#1B3A5C]/40 uppercase tracking-wider font-semibold px-3 mb-2">Admin</p>}
              <div className="space-y-1">
                {adminItems.map(item => (
                  <Link key={item.href} href={item.href} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${pathname === item.href || pathname.startsWith(item.href + '/') ? 'bg-[#1B3A5C] text-white' : 'text-[#1B3A5C]/60 hover:text-[#1B3A5C] hover:bg-white/50'}`}>
                    <span className="text-base flex-shrink-0">{item.icon}</span>{sidebarOpen && <span>{item.label}</span>}
                  </Link>
                ))}
                {sidebarOpen && (
                  <div className="mt-3 pt-3 border-t border-[#c5d4e6]/50 space-y-1">
                    <button onClick={() => window.dispatchEvent(new Event('toggle-cgf'))}
                      className="flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-all text-[#1B3A5C]/40 hover:text-[#1B3A5C] hover:bg-white/50 w-full text-left">
                      <span className="text-sm flex-shrink-0">🔒</span><span>CGF Modus</span>
                    </button>
                    <button onClick={() => window.dispatchEvent(new Event('toggle-corrections'))}
                      className="flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-all text-[#1B3A5C]/40 hover:text-[#1B3A5C] hover:bg-white/50 w-full text-left">
                      <span className="text-sm flex-shrink-0">📋</span><span>Data Source</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </nav>

        <div className="border-t border-[#c5d4e6]">
          <div className="p-4">
            {user ? (
              <>
                {sidebarOpen && <div className="mb-2"><p className="text-xs text-[#1B3A5C]/70 truncate">{profile?.full_name || user.email?.split('@')[0]}</p><p className="text-[10px] text-[#1B3A5C]/40">{profile?.role || 'laden...'}</p></div>}
                <button onClick={handleLogout} className="flex items-center gap-2 text-sm text-[#1B3A5C]/50 hover:text-[#1B3A5C] transition-colors w-full"><span>🚪</span>{sidebarOpen && <span>Uitloggen</span>}</button>
              </>
            ) : (
              <button onClick={() => setShowLogin(true)} className="flex items-center gap-2.5 text-sm text-[#1B3A5C] transition-all w-full px-2 py-2 rounded-lg bg-white/60 hover:bg-white border border-[#c5d4e6] hover:border-[#1B3A5C]/30 shadow-sm">
                <span className="w-7 h-7 rounded-lg bg-[#1B3A5C] flex items-center justify-center flex-shrink-0"><span className="text-white text-xs">🔑</span></span>
                {sidebarOpen && <span className="font-semibold text-[13px]">Inloggen</span>}
              </button>
            )}
          </div>
          {sidebarOpen && <div className="px-4 pb-3"><p className="text-[10px] text-[#1B3A5C]/30 font-mono">{APP_VERSION}</p></div>}
        </div>
      </aside>

      <main className={`flex-1 ${sidebarOpen ? 'ml-64' : 'ml-20'} transition-all duration-300`}>
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-gray-400 hover:text-[#1B3A5C] transition-colors">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 12h18M3 6h18M3 18h18" /></svg>
          </button>
          <div className="flex items-center gap-3">
            <button onClick={handleRefresh} disabled={refreshing} title="Ververs data" className="flex items-center gap-1.5 text-xs text-[#6b7280] hover:text-[#1B3A5C] bg-gray-50 hover:bg-gray-100 border border-gray-200 px-3 py-1.5 rounded-full font-medium transition-all disabled:opacity-50">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={refreshing ? 'animate-spin' : ''}><path d="M21 2v6h-6" /><path d="M3 12a9 9 0 0 1 15-6.7L21 8" /><path d="M3 22v-6h6" /><path d="M21 12a9 9 0 0 1-15 6.7L3 16" /></svg>
              <span className="hidden sm:inline">{refreshing ? 'Verversen...' : 'Ververs'}</span>
            </button>
            {isAdmin && <span className="text-xs bg-amber-50 text-amber-600 px-3 py-1 rounded-full font-medium">Admin</span>}
            <span className="text-xs bg-green-50 text-green-600 px-3 py-1 rounded-full font-medium">Online</span>
          </div>
        </header>
        <div className="p-6">{children}</div>
      </main>

      <div style={{ position: 'fixed', bottom: 0, left: sidebarOpen ? '256px' : '80px', right: 0, background: 'linear-gradient(135deg, #152238 0%, #1B2E4A 100%)', borderTop: '1px solid rgba(75,163,212,0.15)', padding: '10px 32px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', zIndex: 100, transition: 'left 0.3s' }}>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#64748B" strokeWidth="2" strokeLinecap="round"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0110 0v4" /></svg>
        <span style={{ fontSize: '11px', color: '#64748B', letterSpacing: '0.06em', fontFamily: 'monospace' }}>VERGRENDELD</span>
        <span style={{ fontSize: '10px', color: '#475569', margin: '0 8px' }}>·</span>
        <span style={{ fontSize: '10px', color: '#475569', fontFamily: 'monospace' }}>© 2026 Booming Solutions</span>
        <span style={{ fontSize: '10px', color: '#475569', margin: '0 8px' }}>·</span>
        <span style={{ fontSize: '10px', color: '#475569', fontFamily: 'monospace' }}>{APP_VERSION}</span>
      </div>
    </div>
  );
}