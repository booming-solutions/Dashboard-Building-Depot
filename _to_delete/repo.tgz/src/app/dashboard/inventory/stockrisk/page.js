/* ============================================================
   BESTAND: page.js (Stock Risk - Totaaloverzicht)
   KOPIEER NAAR: src/app/dashboard/inventory/stockrisk/page.js
   ============================================================ */
'use client';
import StockRiskShared from '@/components/StockRiskShared';
export default function StockRiskTotaal() { return <StockRiskShared bumFilter={null} />; }
