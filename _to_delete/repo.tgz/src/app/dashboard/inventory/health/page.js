/* ============================================================
   BESTAND: page.js (Gezondheid - Totaaloverzicht)
   KOPIEER NAAR: src/app/dashboard/inventory/health/page.js
   ============================================================ */
'use client';
import HealthDashboardShared from '@/components/HealthDashboardShared';
export default function HealthTotaal() { return <HealthDashboardShared bumFilter={null} />; }
