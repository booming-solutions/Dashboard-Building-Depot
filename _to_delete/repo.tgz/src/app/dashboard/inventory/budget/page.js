/* ============================================================
   BESTAND: page_budget_v2.js
   KOPIEER NAAR: src/app/dashboard/inventory/budget/page.js
   VERSIE: v3.29.1 — dept 11+12 merge in UI

   WIJZIGINGEN T.O.V. v3.29:
   - Dept 12 wordt samengevoegd met 11 (in lijn met andere voorraad-rapporten)
   - Doet de merge op BEIDE velden: raw dept_code (via @/lib/dept-merge helper)
     en effective_dept_code (inline, want de view inventory_data_enriched doet
     wel andere merges zoals 31+32→30, maar nog niet 11+12)

   WIJZIGINGEN T.O.V. v3.28.16:
   - inventory_data → inventory_data_enriched
   - r.bum (PASCAL/HENK/etc) → r.effective_bum_group (afdelings-code)
   - r.dept_code → r.effective_dept_code (voor merges)
   - r.dept_name → r.effective_dept_name
   - Filter pills tonen afdelingsnamen via bum_groups lookup
   - BU_ORDER hardcoded weg → komt nu uit bum_groups.sort_order
   ============================================================ */
'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import { createClient } from '@/lib/supabase';
import { mergeDeptElevenTwelve } from '@/lib/dept-merge';
import LoadingLogo from '@/components/LoadingLogo';
import ExcelExportButton from '@/components/ExcelExportButton';
import { Chart, CategoryScale, LinearScale, BarElement, LineElement, PointElement, BarController, LineController, Tooltip, Legend } from 'chart.js';

Chart.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, BarController, LineController, Tooltip, Legend);

var MN = ['Jan','Feb','Mrt','Apr','Mei','Jun','Jul','Aug','Sep','Okt','Nov','Dec'];
var fmt = function(n) { return (n || 0).toLocaleString('nl-NL', { minimumFractionDigits: 0, maximumFractionDigits: 0 }); };
var fmtK = function(n) { var a = Math.abs(n || 0); return (n < 0 ? '-' : '') + (a >= 1e6 ? (a / 1e6).toFixed(1) + 'M' : (a / 1e3).toFixed(0) + 'K'); };
var fmtP = function(n) { return (n || 0).toFixed(1) + '%'; };
var SN = { '1': 'Curaçao', 'B': 'Bonaire' };
var XCG_USD = 1.82;

function pctColor(pct) {
  var abs = Math.abs(pct || 0);
  if (abs <= 15) return '#16a34a';
  if (abs <= 25) return '#d97706';
  return '#dc2626';
}

function Pill({ label, active, onClick }) {
  return <button className={'px-3 py-1.5 rounded-full text-xs font-semibold cursor-pointer transition-all border whitespace-nowrap ' + (active ? 'bg-[#E84E1B] text-white border-[#E84E1B]' : 'bg-white text-[#6b5240] border-[#e5ddd4] hover:border-[#E84E1B]')} onClick={onClick}>{label}</button>;
}

function PctBar({ pct, name, deptCode, actual, budget }) {
  var _h = useState(false), hovered = _h[0], setHovered = _h[1];
  var capped = Math.max(-80, Math.min(80, pct));
  var isOver = pct > 0;
  var barColor = pctColor(pct);
  var barWidth = Math.min(Math.abs(capped), 80);
  var label = (pct >= 0 ? '+' : '') + Math.round(pct) + '%';
  return (
    <div className="flex items-center gap-2 py-[3px] relative" style={{ minHeight: '28px' }}
      onMouseEnter={function() { setHovered(true); }} onMouseLeave={function() { setHovered(false); }}>
      <div className="w-[180px] text-right text-[10px] text-[#1a0a04] truncate flex-shrink-0 pr-2" title={name}>
        <span className="font-mono text-[#6b5240] mr-1">{deptCode}</span>{name ? name.replace(/^\d+\s*/, '') : ''}
      </div>
      <div className="flex-1 flex items-center relative" style={{ height: '22px' }}>
        <div className="absolute left-1/2 top-0 bottom-0 w-[2px] bg-[#1B3A5C]/40" style={{ zIndex: 2 }}></div>
        <div className="absolute top-0 bottom-0 bg-[#16a34a]/5 border-l border-r border-[#16a34a]/20" style={{ left: 'calc(50% - 7.5%)', width: '15%', zIndex: 0 }}></div>
        <div className="absolute top-0 bottom-0 border-l border-r border-[#d97706]/15" style={{ left: 'calc(50% - 12.5%)', width: '25%', zIndex: 0 }}></div>
        <div className="absolute top-1 bottom-1 rounded-sm transition-all" style={{ backgroundColor: barColor, width: (barWidth / 2) + '%', left: isOver ? '50%' : (50 - barWidth / 2) + '%', zIndex: 1 }}></div>
        <div className="absolute text-[10px] font-bold font-mono whitespace-nowrap" style={{ color: barColor, left: isOver ? (50 + barWidth / 2 + 0.5) + '%' : undefined, right: !isOver ? (50 + barWidth / 2 + 0.5) + '%' : undefined, top: '3px', zIndex: 3 }}>{label}</div>
      </div>
      {hovered && (
        <div style={{ position: 'absolute', left: '200px', top: '-28px', backgroundColor: '#1B3A5C', color: 'white', fontSize: '10px', fontFamily: 'monospace', padding: '5px 10px', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.2)', whiteSpace: 'nowrap', zIndex: 100, pointerEvents: 'none' }}>
          {'Actual: ' + fmt(Math.round(actual || 0)) + '  ·  Budget: ' + fmt(Math.round(budget || 0)) + '  ·  Verschil: ' + fmt(Math.round((actual || 0) - (budget || 0)))}
        </div>
      )}
    </div>
  );
}

export default function InventoryDashboard() {
  var _s = useState;
  var _d = _s([]), data = _d[0], setData = _d[1];
  var _qoo = _s({}), qooData = _qoo[0], setQooData = _qoo[1];   // { 'store|dept': qooValue }
  var _lo = _s(true), loading = _lo[0], setLoading = _lo[1];
  var _vw = _s('overview'), view = _vw[0], setView = _vw[1];
  // Single unified filter state
  var _store = _s('1'), store = _store[0], setStore = _store[1];
  var _bum = _s('all'), selBum = _bum[0], setSelBum = _bum[1];
  var _dept = _s('__total__'), selDept = _dept[0], setSelDept = _dept[1];
  var _bg = _s([]), bumGroups = _bg[0], setBumGroups = _bg[1];  // [{code, display_name, sort_order}]
  var trendRef = useRef(null);
  var chartRef = useRef(null);

  var supabase = createClient();
  useEffect(function() { loadData(); }, []);

  async function loadData() {
    var all = [], from = 0, step = 1000;
    while (true) {
      // Gebruikt enriched view → krijgen effective_dept_code/_name/_bum_group erbij
      var r = await supabase.from('inventory_data_enriched').select('*').order('dept_code').order('inventory_date').range(from, from + step - 1);
      if (!r.data || !r.data.length) break;
      all = all.concat(r.data);
      if (r.data.length < step) break;
      from += step;
    }

    // Load QOO summary view (already aggregated per store_group + dept_code)
    var qoo = await supabase.from('buying_dept_summary').select('*');
    var qooMap = {};
    if (qoo.data) {
      qoo.data.forEach(function(row) {
        qooMap[row.store_group + '|' + row.dept_code] = parseFloat(row.qoo_value) || 0;
      });
    }

    // Load bum_groups voor display namen + volgorde
    var bg = await supabase.from('bum_groups').select('*').eq('active', true).order('sort_order');

    // Eerst: roll dept 12 → 11 op de raw dept_code velden (via shared helper).
    // Daarna: ook op effective_dept_code/_name, want de pagina aggregeert op die velden.
    // De inventory_data_enriched view doet al andere merges (31+32→30) maar nog niet 11+12.
    var merged = mergeDeptElevenTwelve(all);
    // Vind de effective_dept_name van afdeling 11 (als die voorkomt)
    var effNameOf11 = '';
    for (var i = 0; i < merged.length; i++) {
      if (String(merged[i].effective_dept_code || '').trim() === '11' && merged[i].effective_dept_name) {
        effNameOf11 = merged[i].effective_dept_name;
        break;
      }
    }
    merged = merged.map(function(r) {
      if (String(r.effective_dept_code || '').trim() === '12') {
        return Object.assign({}, r, {
          effective_dept_code: '11',
          effective_dept_name: effNameOf11 || r.effective_dept_name,
        });
      }
      return r;
    });
    setData(merged);
    setQooData(qooMap);
    setBumGroups(bg.data || []);
    setLoading(false);
  }

  function buildDepartments(storeFilter, bumFilter) {
    // For 'all': combine CUR + BON, converting BON to XCG
    // For '1': CUR only (already XCG)
    // For 'B': BON only in USD
    var map = {};
    // Budget tracking: per (effective_dept, original_dept) eenmaal het budget setten.
    // Dit zorgt dat:
    //  - Repliceerde rijen in inventory_data (1 budget waarde × N snapshots) maar 1x meetellen
    //  - Bij merge (31+32 → 30) worden de budgets van de originele depts wel opgeteld
    var budgetSeen = {};  // key: 'effectiveCode|originalCode' → true als al verwerkt
    // BumByDept: track per effective_dept_code de meest recente (inventory_date, bum) zodat we
    // de actuele afdelings-toewijzing krijgen, niet de toewijzing van de eerste rij die toevallig binnenkomt.
    var bumByDept = {};  // eCode → { date: ..., bum: ... }
    data.forEach(function(r) {
      if (storeFilter !== 'all' && r.store_number !== storeFilter) return;
      // Gebruik effective_dept_code zodat merges (31+32→30) automatisch worden samengevoegd
      var eCode = r.effective_dept_code || r.dept_code;
      var eName = r.effective_dept_name || r.dept_name;
      var eBum = r.effective_bum_group;
      var key = eCode;
      var isBon = r.store_number === 'B';
      var valMultiplier = (storeFilter === 'all' && isBon) ? XCG_USD : 1;

      if (!map[key]) {
        map[key] = { deptCode: eCode, deptName: eName, bum: eBum, budget: 0, history: {} };
      }
      // Update bum-toewijzing op basis van meest recente inventory_date
      // (voor depts met een time-overgang zoals 71/75 die in 2026 zijn verplaatst)
      var dt = r.inventory_date;
      if (!bumByDept[key] || dt > bumByDept[key].date) {
        bumByDept[key] = { date: dt, bum: eBum, name: eName };
      }
      // Budget: only CUR has budget. Per origineel dept_code maar 1x meetellen.
      // Bij merge (31+32→30) tel je 31's budget + 32's budget bij elkaar (eenmalig elk).
      if (!isBon) {
        var bKey = eCode + '|' + r.dept_code;
        if (!budgetSeen[bKey]) {
          budgetSeen[bKey] = true;
          map[key].budget += parseFloat(r.budget) || 0;
        }
      }

      if (!map[key].history[dt]) map[key].history[dt] = 0;
      map[key].history[dt] += (parseFloat(r.inventory_value) || 0) * valMultiplier;
    });

    // Werk bum en name bij op basis van meest recente inventory_date
    Object.keys(map).forEach(function(k) {
      if (bumByDept[k]) {
        map[k].bum = bumByDept[k].bum;
        map[k].deptName = bumByDept[k].name;
      }
    });

    var list = Object.values(map);
    list.forEach(function(d) {
      // Convert history object to sorted array
      var histArr = Object.entries(d.history).map(function(e) { return { date: e[0], value: e[1] }; });
      histArr.sort(function(a, b) { return a.date.localeCompare(b.date); });
      d.history = histArr;
      d.actual = histArr.length ? histArr[histArr.length - 1].value : 0;
      d.diff = d.actual - d.budget;
      d.pct = d.budget ? ((d.actual - d.budget) / d.budget) * 100 : 0;

      // QOO lookup uit voorgeaggregeerde view
      // Voor 'all' (totaal): som Curacao + Bonaire (Bonaire × XCG_USD voor consistentie)
      var qooVal = 0;
      if (storeFilter === '1') {
        qooVal = qooData['1|' + d.deptCode] || 0;
      } else if (storeFilter === 'B') {
        qooVal = qooData['B|' + d.deptCode] || 0;
      } else {
        qooVal = (qooData['1|' + d.deptCode] || 0) + (qooData['B|' + d.deptCode] || 0) * XCG_USD;
      }
      d.qoo = qooVal;
    });

    // For BON standalone: filter out depts with all-zero history
    if (storeFilter === 'B') {
      list = list.filter(function(d) { return d.history.some(function(h) { return h.value !== 0; }); });
    }

    list.sort(function(a, b) { return (parseInt(a.deptCode) || 999) - (parseInt(b.deptCode) || 999); });
    if (bumFilter && bumFilter !== 'all') list = list.filter(function(d) { return d.bum === bumFilter; });
    return list;
  }

  var departments = useMemo(function() { return buildDepartments(store, selBum); }, [data, store, selBum, qooData]);

  // Bums lijst uit data via effective_bum_group; volgorde uit bum_groups.sort_order
  var bums = useMemo(function() {
    var s = {};
    data.filter(function(r) { return store === 'all' || r.store_number === store; })
        .forEach(function(r) { if (r.effective_bum_group && r.effective_bum_group !== 'OVERIG') s[r.effective_bum_group] = true; });
    var l = Object.keys(s);
    // Sorteer op bum_groups.sort_order
    var orderMap = {};
    bumGroups.forEach(function(g) { orderMap[g.code] = g.sort_order; });
    l.sort(function(a, b) {
      var ai = orderMap[a] != null ? orderMap[a] : 999;
      var bi = orderMap[b] != null ? orderMap[b] : 999;
      return ai - bi;
    });
    return l;
  }, [data, store, bumGroups]);

  // Lookup van afdelings-code naar display naam
  var bumLabel = useMemo(function() {
    var m = {};
    bumGroups.forEach(function(g) { m[g.code] = g.display_name; });
    return m;
  }, [bumGroups]);

  var totals = useMemo(function() { 
    var src = departments;
    if (selDept !== '__total__') src = departments.filter(function(d) { return d.deptCode === selDept; });
    var budget = 0, actual = 0, qoo = 0; 
    src.forEach(function(d) { budget += d.budget; actual += d.actual; qoo += (d.qoo || 0); }); 
    return { budget: budget, actual: actual, qoo: qoo, diff: actual - budget, pct: budget ? ((actual - budget) / budget) * 100 : 0 }; 
  }, [departments, selDept]);

  var dates = useMemo(function() { var s = {}; departments.forEach(function(d) { d.history.forEach(function(h) { s[h.date] = true; }); }); return Object.keys(s).sort(); }, [departments]);
  var historyDates = useMemo(function() { if (dates.length <= 1) return []; return dates.slice(0, -1).reverse(); }, [dates]);

  /* ── Trend chart data ── */
  var trendChartData = useMemo(function() {
    if (!departments.length) return null;
    var allDates = {};
    departments.forEach(function(d) { d.history.forEach(function(h) { allDates[h.date] = true; }); });
    var sortedDates = Object.keys(allDates).sort();
    if (!sortedDates.length) return null;
    var labels = sortedDates.map(function(dt) { var p = dt.split('-'); return parseInt(p[2]) + ' ' + MN[parseInt(p[1]) - 1] + " '" + p[0].slice(2); });
    var title = '', values = [], budgetValues = [];
    if (selDept === '__total__') {
      title = selBum !== 'all' ? ('Totaal ' + selBum) : ('Totaal ' + (store === 'all' ? 'Building Depot' : store === '1' ? 'Curaçao' : 'Bonaire'));
      var totalBudget = 0;
      departments.forEach(function(d) { totalBudget += d.budget; });
      values = sortedDates.map(function(dt) { var sum = 0; departments.forEach(function(d) { var h = d.history.find(function(x) { return x.date === dt; }); if (h) sum += h.value; }); return sum; });
      budgetValues = sortedDates.map(function() { return totalBudget; });
    } else {
      var dept = departments.find(function(d) { return d.deptCode === selDept; });
      if (!dept) return null;
      title = dept.deptCode + ' — ' + dept.deptName;
      values = sortedDates.map(function(dt) { var h = dept.history.find(function(x) { return x.date === dt; }); return h ? h.value : 0; });
      budgetValues = sortedDates.map(function() { return dept.budget; });
    }
    return { labels: labels, values: values, budgetValues: budgetValues, title: title };
  }, [departments, selDept, selBum, store]);

  /* ── Render chart ── */
  useEffect(function() {
    if (chartRef.current) { chartRef.current.destroy(); chartRef.current = null; }
    if (view !== 'visual' || !trendChartData) return;
    var raf = requestAnimationFrame(function() {
      if (!trendRef.current) return;
      chartRef.current = new Chart(trendRef.current, {
        type: 'line',
        data: { labels: trendChartData.labels, datasets: [
          { label: 'Voorraad', data: trendChartData.values, borderColor: '#E84E1B', backgroundColor: 'rgba(232,78,27,0.08)', pointBackgroundColor: '#E84E1B', pointRadius: 5, tension: 0.3, fill: true, borderWidth: 2.5 },
          { label: 'Budget', data: trendChartData.budgetValues, borderColor: '#1B3A5C', borderDash: [6, 3], pointRadius: 0, tension: 0, borderWidth: 2 },
        ] },
        options: { responsive: true, maintainAspectRatio: false,
          plugins: { legend: { position: 'top', labels: { usePointStyle: true, pointStyle: 'circle', padding: 16, font: { size: 11 } } }, tooltip: { callbacks: { label: function(c) { return c.dataset.label + ': ' + fmt(Math.round(c.raw)); } } } },
          scales: { y: { ticks: { callback: function(v) { return fmtK(v); } }, grid: { color: '#f0ebe5' } }, x: { grid: { display: false } } },
        },
      });
    });
    return function() { cancelAnimationFrame(raf); };
  }, [trendChartData, view]);

  if (loading) return <LoadingLogo text="Voorraad rapport laden..." />;
  if (!data.length) return <div className="text-center py-16"><p className="text-[#6b5240]">Geen inventory data beschikbaar.</p></div>;

  var latestDate = dates.length ? dates[dates.length - 1] : '';
  var dateParts = latestDate.split('-');
  var dateLabel = dateParts.length === 3 ? (parseInt(dateParts[2]) + ' ' + MN[parseInt(dateParts[1]) - 1] + ' ' + dateParts[0]) : '';
  var storeName = store === 'all' ? 'Totaal' : store === '1' ? 'Curaçao' : 'Bonaire';
  var currencyLabel = store === 'B' ? 'USD' : 'XCG';
  var isBonaire = store === 'B';
  var isTotaal = store === 'all';

  return (
    <div className="max-w-[1600px] mx-auto" style={{ fontFamily: "'DM Sans', -apple-system, sans-serif", color: '#1a0a04' }}>

      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: '22px', fontWeight: 900 }}>Voorraad vs Budget</h1>
          <p className="text-[13px] text-[#6b5240]">{'Building Depot — ' + storeName + (dateLabel ? ' — data t/m ' + dateLabel : '')}</p>
        </div>
        <div className="border-2 border-[#E84E1B] text-[#E84E1B] px-4 py-1.5 rounded-full text-[13px] font-bold">{storeName + ' · ' + currencyLabel}</div>
      </div>

      {/* Single unified filter block */}
      <div className="bg-white rounded-[14px] border border-[#e5ddd4] p-4 mb-5 space-y-3 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-[11px] text-[#6b5240] font-bold uppercase tracking-[0.8px] w-20">Store</span>
          <div className="flex gap-1">
            <Pill label="Totaal" active={store === 'all'} onClick={function() { setStore('all'); setSelBum('all'); setSelDept('__total__'); }} />
            <Pill label="Curaçao" active={store === '1'} onClick={function() { setStore('1'); setSelBum('all'); setSelDept('__total__'); }} />
            <Pill label="Bonaire" active={store === 'B'} onClick={function() { setStore('B'); setSelBum('all'); setSelDept('__total__'); }} />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-[11px] text-[#6b5240] font-bold uppercase tracking-[0.8px] w-20">Afdeling</span>
          <div className="flex gap-1">
            <Pill label="Alle" active={selBum === 'all'} onClick={function() { setSelBum('all'); setSelDept('__total__'); }} />
            {bums.map(function(b) { return <Pill key={b} label={bumLabel[b] || b} active={selBum === b} onClick={function() { setSelBum(b); setSelDept('__total__'); }} />; })}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-[11px] text-[#6b5240] font-bold uppercase tracking-[0.8px] w-20">Afdeling</span>
          <select value={selDept} onChange={function(e) { setSelDept(e.target.value); }}
            className="bg-white border border-[#e5ddd4] text-[#1a0a04] text-[13px] px-3 py-1.5 rounded-lg min-w-[250px]">
            <option value="__total__">{selBum !== 'all' ? 'Totaal ' + selBum : 'Totaal alle departementen'}</option>
            {departments.map(function(d) { return <option key={d.deptCode} value={d.deptCode}>{d.deptCode + ' - ' + d.deptName}</option>; })}
          </select>
        </div>
        {isBonaire && <div className="text-[11px] text-amber-600 bg-amber-50 px-3 py-2 rounded-lg">Bonaire wordt weergegeven in USD. Budget is nog niet beschikbaar voor Bonaire.</div>}
        {isTotaal && <div className="text-[11px] text-blue-600 bg-blue-50 px-3 py-2 rounded-lg">Totaaloverzicht: Bonaire waarden zijn omgerekend naar XCG (×1.82). Budget geldt alleen voor Curaçao.</div>}
      </div>

      {/* View tabs + export */}
      <div className="flex items-center justify-between mb-5 border-b-2 border-[#e5ddd4]">
        <div className="flex gap-1">
          {[['overview', 'Overzicht'], ['visual', 'Voorraad vs Budget']].map(function(item) {
            return <button key={item[0]} onClick={function() { setView(item[0]); }} className={'px-5 py-2.5 text-[13px] font-semibold border-b-[2.5px] -mb-[2px] transition-colors ' + (view === item[0] ? 'text-[#E84E1B] border-[#E84E1B]' : 'text-[#6b5240] border-transparent hover:text-[#1a0a04]')}>{item[1]}</button>;
          })}
        </div>
        <ExcelExportButton
          filename={(function() { var d = new Date(); var pad = function(n){return n<10?'0'+n:''+n;}; return d.getFullYear() + pad(d.getMonth()+1) + pad(d.getDate()) + '_voorraad_budget_' + (selBum !== 'all' ? (bumLabel[selBum] || selBum).replace(/[ &]/g,'_') : 'alle') + '_' + storeName.replace(/[ç]/g,'c'); })()}
          reportTitle={'Voorraad vs Budget — ' + (selBum !== 'all' ? (bumLabel[selBum] || selBum) + ' — ' : '') + storeName}
          sheets={function() {
            return [{
              name: 'Per Afdeling',
              rows: departments.map(function(d) {
                var row = {
                  'Dept': d.deptCode,
                  'Departement': d.deptName,
                  'Afdeling': bumLabel[d.bum] || d.bum || '',
                };
                if (!isBonaire && !isTotaal) {
                  row['Budget'] = Math.round(d.budget);
                  row['Verschil'] = Math.round(d.diff);
                  row['% vs Budget'] = d.budget ? (Math.round(d.pct * 10) / 10) : null;
                }
                row['Actual'] = Math.round(d.actual);
                row['Besteld (QOO)'] = Math.round(d.qoo || 0);
                historyDates.forEach(function(dt) {
                  var p = dt.split('-');
                  var label = MN[parseInt(p[1]) - 1] + " '" + p[0].slice(2);
                  var h = d.history.find(function(x) { return x.date === dt; });
                  row[label] = h ? Math.round(h.value) : 0;
                });
                return row;
              }),
            }];
          }}
        />
      </div>

      {/* KPI tiles — react to all filters */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-5">
        {[
          { label: 'Budget Voorraad', value: (isBonaire || isTotaal) ? 'n.v.t.' : fmtK(totals.budget), tooltip: (isBonaire || isTotaal) ? '' : fmt(Math.round(totals.budget)) },
          { label: 'Actuele Voorraad', value: fmtK(totals.actual), tooltip: fmt(Math.round(totals.actual)) },
          { label: 'Verschil', value: (isBonaire || isTotaal) ? 'n.v.t.' : ((totals.diff >= 0 ? '+' : '') + fmtK(totals.diff)), color: (isBonaire || isTotaal) ? undefined : pctColor(totals.pct), tooltip: (isBonaire || isTotaal) ? '' : fmt(Math.round(totals.diff)) },
          { label: '% vs Budget', value: (isBonaire || isTotaal) ? 'n.v.t.' : fmtP(totals.pct), color: (isBonaire || isTotaal) ? undefined : pctColor(totals.pct) },
          { label: 'Besteld (QOO)', value: totals.qoo > 0 ? fmtK(totals.qoo) : '-', color: '#1B3A5C', tooltip: totals.qoo > 0 ? fmt(Math.round(totals.qoo)) : '' },
        ].map(function(k, i) {
          return (
            <div key={i} className="bg-white rounded-[14px] border border-[#e5ddd4] p-5 relative overflow-hidden shadow-sm" title={k.tooltip || ''}>
              <div className="absolute top-0 left-0 right-0 h-[3px] bg-[#E84E1B]"></div>
              <p className="text-[11px] text-[#6b5240] font-bold uppercase tracking-[1px]">{k.label}</p>
              <p className="text-[28px] font-semibold font-mono mt-1" style={{ color: k.color || '#1a0a04' }}>{k.value}</p>
              {k.tooltip && <p className="text-[11px] text-[#a08a74] font-mono mt-0.5">{k.tooltip}</p>}
            </div>
          );
        })}
      </div>

      {/* ═══ OVERVIEW TABLE ═══ */}
      {view === 'overview' && (function() {
        var noBudget = isBonaire || isTotaal;
        return (
        <div className="bg-white rounded-[14px] border border-[#e5ddd4] shadow-sm overflow-hidden mb-8">
          <div className="overflow-auto" style={{ maxHeight: '70vh' }}>
            <table className="w-full border-collapse text-[12px]" style={{ minWidth: '900px' }}>
              <thead>
                <tr className="bg-[#1B3A5C]" style={{ position: 'sticky', top: 0, zIndex: 20 }}>
                  <th colSpan={2} className="p-0 border-r border-[#2a4f75] bg-[#1B3A5C]"></th>
                  {!noBudget && <th colSpan={4} className="text-center text-white text-[10px] font-bold uppercase tracking-wider py-2 border-r border-[#2a4f75] bg-[#1B3A5C]">Actual vs Budget</th>}
                  {noBudget && <th className="text-center text-white text-[10px] font-bold uppercase tracking-wider py-2 border-r border-[#2a4f75] bg-[#1B3A5C]">Actual</th>}
                  <th className="text-center text-white text-[10px] font-bold uppercase tracking-wider py-2 border-r border-[#2a4f75] bg-[#1B3A5C]">QOO</th>
                  <th colSpan={historyDates.length} className="text-center text-white text-[10px] font-bold uppercase tracking-wider py-2 bg-[#1B3A5C]">Maandelijks Verloop</th>
                </tr>
                <tr className="bg-[#f0ebe5]" style={{ position: 'sticky', top: '32px', zIndex: 19 }}>
                  <th className="text-left p-2 text-[10px] text-[#6b5240] font-bold uppercase border-b-2 border-[#e5ddd4] bg-[#f0ebe5]">DEP</th>
                  <th className="text-left p-2 text-[10px] text-[#6b5240] font-bold uppercase border-b-2 border-[#e5ddd4] min-w-[140px] border-r border-[#e5ddd4] bg-[#f0ebe5]">Departement</th>
                  {!noBudget && <th className="text-right p-2 text-[10px] text-[#6b5240] font-bold uppercase border-b-2 border-[#e5ddd4] bg-[#f0ebe5]">Budget</th>}
                  <th className={"text-right p-2 text-[10px] text-[#6b5240] font-bold uppercase border-b-2 border-[#e5ddd4] bg-[#f0ebe5]" + (noBudget ? " border-r border-[#e5ddd4]" : "")}>Actual</th>
                  {!noBudget && <th className="text-right p-2 text-[10px] text-[#6b5240] font-bold uppercase border-b-2 border-[#e5ddd4] bg-[#f0ebe5]">Verschil</th>}
                  {!noBudget && <th className="text-right p-2 text-[10px] text-[#6b5240] font-bold uppercase border-b-2 border-[#e5ddd4] border-r border-[#e5ddd4] bg-[#f0ebe5]">%</th>}
                  <th className="text-right p-2 text-[10px] text-[#6b5240] font-bold uppercase border-b-2 border-[#e5ddd4] border-r border-[#e5ddd4] bg-[#f0ebe5]">Besteld (QOO)</th>
                  {historyDates.map(function(dt) { var p = dt.split('-'); return <th key={dt} className="text-right p-2 text-[10px] text-[#6b5240] font-bold uppercase border-b-2 border-[#e5ddd4] whitespace-nowrap bg-[#f0ebe5]">{MN[parseInt(p[1]) - 1] + " '" + p[0].slice(2)}</th>; })}
                </tr>
              </thead>
              <tbody>
                <tr className="bg-[#faf7f4]" style={{ position: 'sticky', top: '64px', zIndex: 18 }}>
                  <td colSpan={2} className="p-2 text-[12px] font-bold border-b-2 border-[#c5bfb3] border-r border-[#e5ddd4] bg-[#faf7f4]">TOTAAL</td>
                  {!noBudget && <td className="p-2 text-right font-mono text-[12px] font-bold border-b-2 border-[#c5bfb3] bg-[#faf7f4]">{fmt(Math.round(totals.budget))}</td>}
                  <td className={"p-2 text-right font-mono text-[12px] font-bold border-b-2 border-[#c5bfb3] bg-[#faf7f4]" + (noBudget ? " border-r border-[#e5ddd4]" : "")}>{fmt(Math.round(totals.actual))}</td>
                  {!noBudget && <td className="p-2 text-right font-mono text-[12px] font-bold border-b-2 border-[#c5bfb3] bg-[#faf7f4]" style={{ color: pctColor(totals.pct) }}>{fmt(Math.round(totals.diff))}</td>}
                  {!noBudget && <td className="p-2 text-right font-mono text-[12px] font-bold border-b-2 border-[#c5bfb3] border-r border-[#e5ddd4] bg-[#faf7f4]" style={{ color: pctColor(totals.pct) }}>{totals.budget ? fmtP(totals.pct) : '-'}</td>}
                  <td className="p-2 text-right font-mono text-[12px] font-bold border-b-2 border-[#c5bfb3] border-r border-[#e5ddd4] bg-[#faf7f4]" style={{ color: '#1B3A5C' }}>{totals.qoo > 0 ? fmt(Math.round(totals.qoo)) : '-'}</td>
                  {historyDates.map(function(dt) { var sum = 0; departments.forEach(function(d) { var h = d.history.find(function(x) { return x.date === dt; }); if (h) sum += h.value; }); return <td key={dt} className="p-2 text-right font-mono text-[12px] font-bold border-b-2 border-[#c5bfb3] bg-[#faf7f4]">{fmt(Math.round(sum))}</td>; })}
                </tr>
                {departments.map(function(d, i) {
                  var dc = pctColor(d.pct);
                  return (
                    <tr key={d.deptCode} className={(i % 2 === 0 ? 'bg-white' : 'bg-[#fdfcfb]') + ' hover:bg-[#faf5f0] cursor-pointer'} onClick={function() { setSelDept(d.deptCode); setView('visual'); }}>
                      <td className="p-2 text-[12px] text-[#6b5240] border-b border-[#f0ebe5] font-mono">{d.deptCode}</td>
                      <td className="p-2 text-[12px] border-b border-[#f0ebe5] border-r border-[#e5ddd4] truncate max-w-[180px]" title={d.deptName}>{d.deptName}</td>
                      {!noBudget && <td className="p-2 text-right font-mono text-[12px] border-b border-[#f0ebe5]">{fmt(Math.round(d.budget))}</td>}
                      <td className={"p-2 text-right font-mono text-[12px] border-b border-[#f0ebe5]" + (noBudget ? " border-r border-[#e5ddd4]" : "")}>{fmt(Math.round(d.actual))}</td>
                      {!noBudget && <td className="p-2 text-right font-mono text-[12px] border-b border-[#f0ebe5]" style={{ color: dc }}>{fmt(Math.round(d.diff))}</td>}
                      {!noBudget && <td className="p-2 text-right font-mono text-[12px] border-b border-[#f0ebe5] border-r border-[#e5ddd4]" style={{ color: dc }}>{d.budget ? fmtP(d.pct) : '-'}</td>}
                      <td className="p-2 text-right font-mono text-[12px] border-b border-[#f0ebe5] border-r border-[#e5ddd4]" style={{ color: '#1B3A5C' }}>{(d.qoo || 0) > 0 ? fmt(Math.round(d.qoo)) : '-'}</td>
                      {historyDates.map(function(dt) { var h = d.history.find(function(x) { return x.date === dt; }); return <td key={dt} className="p-2 text-right font-mono text-[11px] border-b border-[#f0ebe5] text-[#6b5240]">{h ? fmt(Math.round(h.value)) : '-'}</td>; })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        );
      })()}

      {/* ═══ VOORRAAD VS BUDGET (trend + bar chart) ═══ */}
      {view === 'visual' && (
        <div className="space-y-5 mb-8">
          {/* Trend chart */}
          {trendChartData && (
            <div className="bg-white rounded-[14px] border border-[#e5ddd4] p-5 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-[15px] font-bold">{trendChartData.title}</h3>
                  <p className="text-[12px] text-[#6b5240]">
                    {'Store: ' + (store === 'all' ? 'Totaal' : store === '1' ? 'Curaçao' : 'Bonaire') +
                    ' · Budget: ' + fmt(Math.round(trendChartData.budgetValues[0] || 0)) +
                    ' · Actual: ' + fmt(Math.round(trendChartData.values[trendChartData.values.length - 1] || 0))}
                  </p>
                </div>
                {trendChartData.budgetValues[0] > 0 && (function() {
                  var lastVal = trendChartData.values[trendChartData.values.length - 1] || 0;
                  var budVal = trendChartData.budgetValues[0] || 1;
                  var p = ((lastVal - budVal) / budVal) * 100;
                  return <span className="text-[20px] font-bold font-mono" style={{ color: pctColor(p) }}>{(p >= 0 ? '+' : '') + fmtP(p)}</span>;
                })()}
              </div>
              <div style={{ height: '320px' }}>
                <canvas ref={trendRef}></canvas>
              </div>
            </div>
          )}

          {/* Bar chart - only for Curacao (has budget) */}
          {store === '1' && (
            <div className="bg-white rounded-[14px] border border-[#e5ddd4] shadow-sm p-6" style={{ overflow: 'visible' }}>
              <h3 className="text-[15px] font-bold mb-1">Procentueel verschil per departement</h3>
              <p className="text-[12px] text-[#6b5240] mb-2">t.o.v. budget — hover voor details</p>
              <div className="flex items-center gap-4 text-[10px] mb-4">
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm" style={{ backgroundColor: '#16a34a' }}></span> Binnen ±15%</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm" style={{ backgroundColor: '#d97706' }}></span> 15-25%</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm" style={{ backgroundColor: '#dc2626' }}></span> Meer dan 25%</span>
              </div>
              <div style={{ overflow: 'visible' }}>
                {departments.filter(function(d) { return d.budget > 0; }).map(function(d) {
                  return <PctBar key={d.deptCode} pct={d.pct} name={d.deptName} deptCode={d.deptCode} actual={d.actual} budget={d.budget} />;
                })}
              </div>
            </div>
          )}

          {store !== '1' && (
            <div className="bg-white rounded-[14px] border border-[#e5ddd4] p-8 shadow-sm text-center">
              <p className="text-[13px] text-amber-600">{store === 'B' ? 'Bonaire heeft geen budget — visuele vergelijking niet beschikbaar.' : 'Budget vergelijking alleen beschikbaar voor Curaçao.'}</p>
            </div>
          )}
        </div>
      )}

      {/* Legend */}
      <div className="bg-white rounded-[14px] border border-[#e5ddd4] p-4 shadow-sm mb-5">
        <div className="flex flex-wrap gap-5 text-[10px] text-[#6b5240]">
          <span style={{ color: '#16a34a' }}>Groen = binnen ±15% van budget</span>
          <span style={{ color: '#d97706' }}>Oranje = 15-25% afwijking</span>
          <span style={{ color: '#dc2626' }}>Rood = meer dan 25% afwijking</span>
          <span>Klik op een rij in het overzicht om de trend te bekijken</span>
        </div>
      </div>

      {/* Voetnoot QOO */}
      <div className="bg-[#faf7f4] rounded-[14px] border border-[#e5ddd4] p-5 shadow-sm">
        <h3 className="text-[13px] font-bold mb-2 text-[#1a0a04]">Over de kolom &quot;Besteld (QOO)&quot;</h3>
        <p className="text-[11px] text-[#6b5240] leading-relaxed mb-2">
          QOO (Quantity on Order) is de geschatte waarde van openstaande bestellingen per departement. Het is een <b>indicatie</b>, geen exacte waarde,
          en sluit daarom niet 100% aan op de cijfers in Eagle of Compass. Hieronder uitleg over hoe dit cijfer tot stand komt.
        </p>
        <div className="bg-white border border-[#e5ddd4] rounded-lg p-3 text-[11px] text-[#1a0a04] mb-2">
          <div className="font-bold mb-1">Berekening:</div>
          <div className="font-mono text-[10px]">QOO-waarde per item = aantal stuks op order × eenheidsprijs</div>
          <div className="font-mono text-[10px]">eenheidsprijs = inv_value_at_cost ÷ qoh (per item, gemiddeld over stores)</div>
        </div>
        <p className="text-[11px] text-[#6b5240] leading-relaxed mb-1"><b>Waarom is het een schatting:</b></p>
        <ul className="text-[11px] text-[#6b5240] leading-relaxed list-disc pl-5 space-y-0.5">
          <li>De Compass-export bevat geen vaste inkoopprijs per stuk; deze wordt afgeleid uit de voorraadwaarde gedeeld door de hoeveelheid op voorraad.</li>
          <li>Voor items die op geen enkele store voorraad hebben (qoh = 0 overal), kan geen eenheidsprijs worden berekend. Deze items tellen niet mee in de QOO-waarde, ook al zijn ze wel besteld.</li>
          <li>De afgeleide eenheidsprijs is een momentopname en kan licht afwijken van de werkelijke inkoopprijs op de bestelbon.</li>
          <li>Voor het Totaaloverzicht wordt de Bonaire-waarde omgerekend naar XCG (×1,82), conform de Actual-kolom.</li>
        </ul>
        <p className="text-[11px] text-[#6b5240] leading-relaxed mt-2">
          Voor de meeste departementen ligt de dekking tussen 85% en 100% van de besteldé items.
          Gebruik deze kolom als <b>indicator</b> of er voldoende bestellingen onderweg zijn om een tekort op te vangen — niet als financiële verplichting.
        </p>
      </div>
    </div>
  );
}
